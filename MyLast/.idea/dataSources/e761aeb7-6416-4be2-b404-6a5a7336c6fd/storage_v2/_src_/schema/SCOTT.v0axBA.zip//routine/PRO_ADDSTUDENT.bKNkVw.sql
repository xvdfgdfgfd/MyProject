CREATE procedure pro_addStudent
as
begin
insert into t_student values(s_sq.nextval,'yy',30,'男');
insert into t_student values(s_sq.nextval,'yy',30,'男');
insert into t_student values(s_sq.nextval,'yy',30,'男');
commit;
end;
/

