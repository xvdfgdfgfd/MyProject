CREATE VIEW S_STU_VIEW AS
  select s_name from t_student
with check option
/

